let eyeicon = document.getElementById("eyeicon")
let Password = document.getElementById("password")

eyeicon.onclick = function(){
    if(Password.type == "password"){
        Password.type = "text";
        eyeicon.src = "./assets/image/eye-open.png";
    }else{
        Password.type = "password"
        eyeicon.src = "./assets/image/eye-close.png";
    }
}